# TikTok to Facebook Reels Bot
This bot auto-reuploads TikTok videos to Facebook Reels via Telegram.
