# Handles Telegram commands
